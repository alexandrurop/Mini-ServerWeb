﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Proiect_baze.Data;
using Proiect_baze.Modele;
using Proiect_baze.Servicii;

namespace Proiect_baze.Views
{
    public partial class HRView : UserControl
    {
        public HRView()
        {
            InitializeComponent();
        }

        private void HRView_Loaded(object sender, RoutedEventArgs e)
        {
            IncarcaCereri();
            IncarcaStatistici();
            IncarcaDepartamente();
            IncarcaAniversari();
            IncarcaDate();
            IncarcaAngajati();

            //IncarcaChartDepartamente();


            // sefii se vor incarca doar dupa alegerea departamentului
            SefCombo.ItemsSource = null;
        }



        private void IncarcaCereri()
        {
            using (var db = new AppDbContext())
            {
                CereriGrid.ItemsSource = db.CereriConcediu.ToList();
            }
        }

        private void Aproba_Click(object sender, RoutedEventArgs e)
        {
            if (CereriGrid.SelectedItem is CerereConcediu cerere)
            {
                using (var db = new AppDbContext())
                {
                    var c = db.CereriConcediu.Find(cerere.Id);
                    c.Stare = StareCerere.Aprobata;

                    db.AprobariConcediu.Add(new AprobareConcediu
                    {
                        CerereConcediuId = c.Id,
                        ManagerId = 3, // HR manager
                        DataAprobarii = DateTime.Now,
                        Aprobata = true
                    });

                    db.SaveChanges();
                }

                IncarcaCereri();
            }
        }

        private void IncarcaStatistici()
        {
            var service = new StatisticiService();

            DepartamenteGrid.ItemsSource =
                service.AngajatiPeDepartament() as System.Collections.IEnumerable;

            AniversariGrid.ItemsSource =
                service.AniversariAzi() as System.Collections.IEnumerable;
        }



        private void Respinge_Click(object sender, RoutedEventArgs e)
        {
            if (CereriGrid.SelectedItem is CerereConcediu cerere)
            {
                using (var db = new AppDbContext())
                {
                    var c = db.CereriConcediu.Find(cerere.Id);
                    c.Stare = StareCerere.Respinsa;
                    db.SaveChanges();
                }

                IncarcaCereri();
            }
        }


        private void GenereazaFluturasi_Click(object sender, RoutedEventArgs e)
        {
            int luna = DateTime.Now.Month;
            int an = DateTime.Now.Year;

            var salarizare = new SalarizareService();

            using (var db = new AppDbContext())
            {
                var angajati = db.Angajati.Select(a => a.Id).ToList();

                foreach (var angajatId in angajati)
                {
                    // verific sa nu existe deja fluturas
                    bool exista = db.Fluturasi.Any(f =>
                        f.AngajatId == angajatId &&
                        f.Luna == luna &&
                        f.An == an);

                    if (!exista)
                    {
                        salarizare.GenereazaFluturas(angajatId, luna, an);
                    }
                }
            }

            MessageBox.Show("Fluturasii au fost generati!");
        }


private void CreeazaAngajat_Click(object sender, RoutedEventArgs e)
{
    try
    {
        using (var db = new AppDbContext())
        {
            
            if (string.IsNullOrWhiteSpace(NumeBox.Text) ||
                string.IsNullOrWhiteSpace(PrenumeBox.Text) ||
                DepartamentCombo.SelectedValue == null ||
                PozitieCombo.SelectedValue == null ||
                DataAngajarePicker.SelectedDate == null ||
                string.IsNullOrWhiteSpace(SalariuBox.Text))
            {
                MessageBox.Show("Completeaza toate campurile obligatorii.");
                return;
            }

            if (!decimal.TryParse(SalariuBox.Text, out decimal salariu))
            {
                MessageBox.Show("Salariul brut nu este valid.");
                return;
            }

            var angajat = new Angajat
            {
                Nume = NumeBox.Text,
                Prenume = PrenumeBox.Text,
                DataNastere = DataNasterePicker.SelectedDate.Value,
                DataAngajare = DataAngajarePicker.SelectedDate.Value,
                DepartamentId = (int)DepartamentCombo.SelectedValue,
                PozitieId = (int)PozitieCombo.SelectedValue,
                SefId = SefCombo.SelectedValue as int?,
                SalariuBrut = salariu,
                Activ = true
            };

            db.Angajati.Add(angajat);
            db.SaveChanges(); 

            var utilizator = new Utilizator
            {
                Username = UsernameBox.Text,
                Parola = ParolaBox.Password,
                Rol = Rol.Employee,
                AngajatId = angajat.Id
            };

            db.Utilizatori.Add(utilizator);
            db.SaveChanges();
        }

        MessageBox.Show("Angajat si cont create cu succes!");
    }
    catch (Exception ex)
    {
        MessageBox.Show(
            "Eroare la creare angajat:\n\n" + ex.Message,
            "Eroare",
            MessageBoxButton.OK,
            MessageBoxImage.Error
        );
    }
}

        private void IncarcaDepartamente()
        {
            var service = new StatisticiService();
            DepartamenteGrid.ItemsSource = service.AngajatiPeDepartament();
        }


        private void IncarcaAniversari()
        {
            var service = new StatisticiService();
            AniversariGrid.ItemsSource = service.AniversariAzi();
        }


        private void IncarcaDate()
        {
            using (var db = new AppDbContext())
            {
                DepartamentCombo.ItemsSource = db.Departamente.ToList();
                PozitieCombo.ItemsSource = db.Pozitii.ToList();
                SefCombo.ItemsSource = db.Angajati.ToList();
            }
        }

        //private void IncarcaSefi()
        //{
        //    using (var db = new AppDbContext())
        //    {
        //        var sefi = db.Angajati
        //            .Where(a => a.Activ)
        //            .Select(a => new
        //            {
        //                a.Id,
        //                NumeComplet = a.Nume + " " + a.Prenume
        //            })
        //            .ToList();

        //        SefCombo.ItemsSource = sefi;
        //    }
        //}

        //pt a putea alege la creare angajat - doar seful din acelasi departament, nu din alte departamente, n-are sens
        private void DepartamentCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (DepartamentCombo.SelectedValue == null)
                return;

            int departamentId = (int)DepartamentCombo.SelectedValue;

            using (var db = new AppDbContext())
            {
                var sefi = db.Angajati
                    .Where(a => a.DepartamentId == departamentId && a.Activ)
                    .Select(a => new
                    {
                        a.Id,
                        NumeComplet = a.Nume + " " + a.Prenume
                    })
                    .ToList();

                SefCombo.ItemsSource = sefi;
                SefCombo.SelectedIndex = -1;
            }
        }


        //metoda pentru incarcare angajaiilor in ecranul hr ului, pt a putea sa ii vizualizeze pe toti
        private void IncarcaAngajati()
        {
            using (var db = new AppDbContext())
            {
                var angajati = from a in db.Angajati
                               join d in db.Departamente on a.DepartamentId equals d.Id
                               join p in db.Pozitii on a.PozitieId equals p.Id
                               join s in db.Angajati on a.SefId equals s.Id into sefi
                               from sef in sefi.DefaultIfEmpty()
                               select new
                               {
                                   NumeComplet = a.Nume + " " + a.Prenume,
                                   Departament = d.Nume,
                                   Pozitie = p.Nume,
                                   Sef = sef != null ? sef.Nume + " " + sef.Prenume : "-",
                                   a.DataAngajare,
                                   a.SalariuBrut,
                                  
                               };

                AngajatiGrid.ItemsSource = angajati.ToList();
            }
        }


        //pt chart pie ul pe departamente(statistica cati sunt in fiecare departament)
        //private void IncarcaChartDepartamente()
        //{
        //    using (var db = new AppDbContext())
        //    {
        //        var dateChart = db.Angajati
        //            .GroupBy(a => a.Departament.Nume)
        //            .Select(g => new
        //            {
        //                Departament = g.Key,
        //                Numar = g.Count()
        //            })
        //            .ToList();

        //        DepartamenteChart.DataContext = dateChart;
        //    }
        //}



    }
}
