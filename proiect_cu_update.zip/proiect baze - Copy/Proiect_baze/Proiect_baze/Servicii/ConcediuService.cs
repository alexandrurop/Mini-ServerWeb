﻿using System;
using System.Linq;
using Proiect_baze.Data;
using Proiect_baze.Modele;

namespace Proiect_baze.Servicii
{
    public class ConcediuService
    {
        //angajatul ce creeaza cererea de concediu
        public void CreeazaCerere(int angajatId, TipConcediu tip, DateTime start, DateTime end)
        {
            using (var db = new AppDbContext())
            {
                var cerere = new CerereConcediu
                {
                    AngajatId = angajatId,
                    Tip = tip,
                    DataStart = start,
                    DataSfarsit = end,
                    Stare = StareCerere.InAsteptare,
                    DataCreare = DateTime.Now
                };

                db.CereriConcediu.Add(cerere);
                db.SaveChanges(); // ← AICI apare în SQL
            }
        }

        //managerul ce aproba sau refuza cererea de concediu
        public void AprobaCerere(int cerereId, int managerId, bool aprobat)
        {
            using (var db = new AppDbContext())
            {
                var cerere = db.CereriConcediu.Find(cerereId);

                cerere.Stare = aprobat
                    ? StareCerere.Aprobata
                    : StareCerere.Respinsa;

                db.AprobariConcediu.Add(new AprobareConcediu
                {
                    CerereConcediuId = cerereId,
                    ManagerId = managerId,
                    DataAprobarii = DateTime.Now,
                    Aprobata = aprobat
                });

                db.SaveChanges(); 
            }
        }
    }
}
