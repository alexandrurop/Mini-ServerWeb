﻿using System;
using System.Linq;
using Proiect_baze.Data;
using Proiect_baze.Modele;
using System.Collections.Generic;

namespace Proiect_baze.Servicii
{
    public class StatisticiService
    {
        public int NrAngajatiDepartament(int departamentId)
        {
            using (var db = new AppDbContext())
                return db.Angajati.Count(a => a.DepartamentId == departamentId);
        }


        public int ZileRamase(int angajatId)
        {
            using (var db = new AppDbContext())
            {
                var cereriAprobate = db.CereriConcediu
                    .Where(c => c.AngajatId == angajatId &&
                                c.Stare == StareCerere.Aprobata)
                    .ToList(); 

                int zileFolosite = cereriAprobate.Sum(c =>
                    (c.DataSfarsit - c.DataStart).Days + 1);

                return 24 - zileFolosite;
            }
        }


        public IEnumerable<dynamic> AngajatiPeDepartament()
        {
            using (var db = new AppDbContext())
            {
                return db.Angajati
                    .GroupBy(a => a.Departament.Nume)
                    .Select(g => new
                    {
                        Departament = g.Key,
                        Numar = g.Count()
                    })
                    .ToList();
            }

        }

        public IEnumerable<dynamic> AniversariAzi()
        {
            DateTime azi = DateTime.Today;

            using (var db = new AppDbContext())
            {
                return db.Angajati
                    .Where(a =>
                        a.DataNastere.Day == azi.Day &&
                        a.DataNastere.Month == azi.Month)
                    .Select(a => new
                    {
                        a.Nume,
                        a.Prenume,
                        DataNastere = a.DataNastere,
                        Departament = a.Departament.Nume
                    })
                    .ToList();
            }
        }





    }
}
