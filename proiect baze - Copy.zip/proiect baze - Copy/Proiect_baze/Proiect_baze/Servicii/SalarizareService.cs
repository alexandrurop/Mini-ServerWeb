﻿using System;
using System.Linq;
using Proiect_baze.Data;
using Proiect_baze.Modele;

namespace Proiect_baze.Servicii
{
    public class SalarizareService
    {
        public FluturasSalariu GenereazaFluturas( int angajatId, int luna, int an)
        {
            using (var db = new AppDbContext())
            {
                var contract = db.ContracteSalariu
                    .FirstOrDefault(c => c.AngajatId == angajatId);

                var pontaj = db.Pontaje
                    .FirstOrDefault(p => p.AngajatId == angajatId &&
                                         p.Luna == luna &&
                                         p.An == an);

                if (contract == null )
                    return null;

                decimal brut = 
                    pontaj.OreLucrate * contract.ValoareOra +
                    pontaj.OreSuplimentare * contract.ValoareOra * 1.75m;

                decimal net = brut * 0.65m;

                var fluturas = new FluturasSalariu
                {
                    AngajatId = angajatId,
                    Luna = luna,
                    An = an,
                    Brut = Math.Round(brut, 2),
                    Net = Math.Round(net, 2),
                    GeneratLa = DateTime.Now
                };

                //db.Fluturasi.Add(fluturas);
                //db.SaveChanges();

                return fluturas;
            }
        }
    }
}
