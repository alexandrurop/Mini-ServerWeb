﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using System.Windows;

namespace Proiect_baze.Views
{
    public partial class PontajDialog : Window
    {
        public int OreLucrate { get; set; }
        public int OreSuplimentare { get; set; }

        public PontajDialog(string nume)
        {
            InitializeComponent();
            NumeAngajatText.Text = "Pontaj pentru: " + nume;
        }

        private void OK_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(OreLucrateBox.Text, out int ol) && int.TryParse(OreSuplimentareBox.Text, out int os))
            {
                OreLucrate = ol;
                OreSuplimentare = os;
                this.DialogResult = true; 
            }
            else
            {
                MessageBox.Show("Te rog introdu numere întregi valide pentru ore.");
            }
        }
    }
}
