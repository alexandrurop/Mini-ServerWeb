﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Proiect_baze.Data;
using Proiect_baze.Modele;
using Proiect_baze.Servicii;

namespace Proiect_baze.Views
{
    public partial class EmployeeView : UserControl
    {
        private Utilizator _user;

        public EmployeeView(Utilizator user)
        {
            InitializeComponent();
            _user = user;

            AfiseazaZileRamase();
            IncarcaCererile();
            IncarcaFluturasi();
        }

        private void IncarcaCererile()
        {
            using (var db = new AppDbContext())
            {
                var cereriCuNume = from c in db.CereriConcediu
                                   join a in db.Angajati on c.AngajatId equals a.Id
                                   where c.AngajatId == _user.AngajatId
                                   select new
                                   {
                                       c.Id,
                                       c.AngajatId,
                                       Angajat = a.Nume + " " + a.Prenume, 
                                       c.Tip,
                                       c.DataStart,
                                       c.DataSfarsit,
                                       c.Stare,
                                       c.DataCreare
                                   };

                CererileGrid.ItemsSource = cereriCuNume.ToList();
            }
        }


        private void AfiseazaZileRamase()
        {
            var service = new StatisticiService();
            int ramase = service.ZileRamase(_user.AngajatId.Value);

            ZileRamaseText.Text = $"Zile concediu rămase: {ramase}";
        }


        private void IncarcaFluturasi()
        {
            using (var db = new AppDbContext())
            {
                var fluturasiCuNume = from f in db.Fluturasi
                                      join a in db.Angajati on f.AngajatId equals a.Id
                                      where f.AngajatId == _user.AngajatId
                                      select new
                                      {
                                          f.Id,
                                          f.AngajatId,
                                          Angajat = a.Nume + " " + a.Prenume, 
                                          f.Luna,
                                          f.An,
                                          f.Brut,
                                          f.Net,
                                          f.Taxe,
                                          f.GeneratLa
                                      };

                FluturasiGrid.ItemsSource = fluturasiCuNume.ToList();
            }
        }

        private void TrimiteCerere_Click(object sender, RoutedEventArgs e)
        {
            if (DataStartPicker.SelectedDate == null || DataEndPicker.SelectedDate == null)
            {
                MessageBox.Show("Selecteaza datele!");
                return;
            }

            var tip = TipConcediuBox.SelectedIndex == 1
                ? TipConcediu.Medical
                : TipConcediu.Anual;

            using (var db = new AppDbContext())
            {
                var cerere = new CerereConcediu
                {
                    AngajatId = _user.AngajatId.Value,
                    DataStart = DataStartPicker.SelectedDate.Value,
                    DataSfarsit = DataEndPicker.SelectedDate.Value,
                    Tip = tip,
                    Stare = StareCerere.InAsteptare,
                    DataCreare = DateTime.Now
                };

                db.CereriConcediu.Add(cerere);
                db.SaveChanges();
            }

            MessageBox.Show("Cerere trimisa!");
            IncarcaCererile();
        }
    }
}
