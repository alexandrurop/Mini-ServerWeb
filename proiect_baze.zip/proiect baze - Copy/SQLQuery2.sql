﻿USE HRMS_DB;
GO

--------------------------------------------------
-- 1. CURĂȚARE DATE (ORDINE CORECTĂ)
--------------------------------------------------
DELETE FROM FluturasSalarius;
DELETE FROM PontajLunars;
DELETE FROM AprobareConcedius;
DELETE FROM CerereConcedius;
DELETE FROM ContractSalarius;
DELETE FROM Utilizators;
DELETE FROM Angajats;
DELETE FROM Pozities;
DELETE FROM Departaments;
GO

--------------------------------------------------
-- 2. DEPARTAMENTE
--------------------------------------------------
INSERT INTO Departaments (Nume)
VALUES
('Resurse Umane'),
('IT'),
('Vanzari'),
('Logistica');
GO

--------------------------------------------------
-- 3. POZIȚII
--------------------------------------------------
INSERT INTO Pozities (Nume)
VALUES
('HR Manager'),
('Software Developer'),
('Manager Vanzari'),
('Contabil');
GO

--------------------------------------------------
-- 4. ANGAJAȚI (FĂRĂ ID HARDCODAT)
--------------------------------------------------

-- Zlataru Victor – HR Manager
INSERT INTO Angajats
(Nume, Prenume, DataNastere, DataAngajare, Activ,
 DepartamentId, PozitieId, SefId, SalariuBrut)
SELECT
'Zlataru',
'Victor',
'1995-05-15',
'2023-01-10',
1,
d.Id,
p.Id,
NULL,
8000
FROM Departaments d
JOIN Pozities p ON p.Nume = 'HR Manager'
WHERE d.Nume = 'Resurse Umane';
GO

-- Ropcean Alexandru – IT
INSERT INTO Angajats
(Nume, Prenume, DataNastere, DataAngajare, Activ,
 DepartamentId, PozitieId, SefId, SalariuBrut)
SELECT
'Ropcean',
'Alexandru',
'1996-08-20',
'2023-02-15',
1,
d.Id,
p.Id,
(SELECT Id FROM Angajats WHERE Nume='Zlataru' AND Prenume='Victor'),
9500
FROM Departaments d
JOIN Pozities p ON p.Nume = 'Software Developer'
WHERE d.Nume = 'IT';
GO

-- Popescu Ion – Vânzări
INSERT INTO Angajats
(Nume, Prenume, DataNastere, DataAngajare, Activ,
 DepartamentId, PozitieId, SefId, SalariuBrut)
SELECT
'Popescu',
'Ion',
'1990-01-01',
'2022-05-20',
1,
d.Id,
p.Id,
(SELECT Id FROM Angajats WHERE Nume='Zlataru' AND Prenume='Victor'),
6000
FROM Departaments d
JOIN Pozities p ON p.Nume = 'Manager Vanzari'
WHERE d.Nume = 'Vanzari';
GO

-- Ionescu Maria – IT
INSERT INTO Angajats
(Nume, Prenume, DataNastere, DataAngajare, Activ,
 DepartamentId, PozitieId, SefId, SalariuBrut)
SELECT
'Ionescu',
'Maria',
'1998-11-12',
'2024-01-05',
1,
d.Id,
p.Id,
(SELECT Id FROM Angajats WHERE Nume='Ropcean' AND Prenume='Alexandru'),
7000
FROM Departaments d
JOIN Pozities p ON p.Nume = 'Software Developer'
WHERE d.Nume = 'IT';
GO

-- Georgescu Ana – Logistică
INSERT INTO Angajats
(Nume, Prenume, DataNastere, DataAngajare, Activ,
 DepartamentId, PozitieId, SefId, SalariuBrut)
SELECT
'Georgescu',
'Ana',
'1992-03-25',
'2021-06-15',
1,
d.Id,
p.Id,
(SELECT Id FROM Angajats WHERE Nume='Zlataru' AND Prenume='Victor'),
5500
FROM Departaments d
JOIN Pozities p ON p.Nume = 'Contabil'
WHERE d.Nume = 'Logistica';
GO

--------------------------------------------------
-- 5. UTILIZATORI (LOGIN)
-- Rol: 0 = HRManager, 1 = Employee
--------------------------------------------------
INSERT INTO Utilizators (Username, Parola, Rol, AngajatId)
SELECT 'sef', 'hr', 0, Id
FROM Angajats WHERE Nume='Zlataru' AND Prenume='Victor';

INSERT INTO Utilizators (Username, Parola, Rol, AngajatId)
SELECT 'victor.zlataru', 'parola123', 1, Id
FROM Angajats WHERE Nume='Zlataru' AND Prenume='Victor';

INSERT INTO Utilizators (Username, Parola, Rol, AngajatId)
SELECT 'alex.ropcean', 'parola456', 1, Id
FROM Angajats WHERE Nume='Ropcean' AND Prenume='Alexandru';

INSERT INTO Utilizators (Username, Parola, Rol, AngajatId)
SELECT 'ion.popescu', 'user789', 1, Id
FROM Angajats WHERE Nume='Popescu' AND Prenume='Ion';
GO

--------------------------------------------------
-- 6. CONTRACTE SALARIU (AUTOMAT)
--------------------------------------------------
INSERT INTO ContractSalarius
(AngajatId, SalariuBrut, ValoareOra, DataStart)
SELECT
Id,
SalariuBrut,
SalariuBrut / 160.0,
DataAngajare
FROM Angajats;
GO

--------------------------------------------------
-- 7. PONTAJ LUNAR
--------------------------------------------------
INSERT INTO PontajLunars
(AngajatId, Luna, An, OreLucrate, OreSuplimentare)
SELECT
Id,
1,
2026,
160,
5
FROM Angajats;
GO

--------------------------------------------------
-- 8. CERERI CONCEDIU (TEST WORKFLOW)
--------------------------------------------------
INSERT INTO CerereConcedius
(AngajatId, Tip, DataStart, DataSfarsit, Stare, DataCreare)
SELECT
Id,
0, -- concediu normal
'2026-02-01',
'2026-02-05',
0, -- InAsteptare
GETDATE()
FROM Angajats
WHERE Nume='Ropcean' AND Prenume='Alexandru';
GO
