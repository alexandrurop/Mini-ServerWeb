﻿using System;
using System.Linq;
using Proiect_baze.Data;
using Proiect_baze.Modele;
using System.Collections.Generic;

namespace Proiect_baze.Servicii
{
    public class StatisticiService
    {
        public int NrAngajatiDepartament(int departamentId)
        {
            using (var db = new AppDbContext())
                return db.Angajati.Count(a => a.DepartamentId == departamentId);
        }

        public int ZileConcediuRamase(int angajatId)
        {
            using (var db = new AppDbContext())
            {
                var angajat = db.Angajati.Find(angajatId);
                if (angajat == null) return 0;

                // Calculăm lunile de la angajare (maxim 24 luni conform regulii)
                int luniVechime = ((DateTime.Today.Year - angajat.DataAngajare.Year) * 12) + DateTime.Today.Month - angajat.DataAngajare.Month;
                int luniEligibile = Math.Min(luniVechime, 24); // Nu acumulăm mai mult de 2 ani

                int totalZileAcumulate = luniEligibile * 2; // 2 zile pe lună

                int zileLuate = db.CereriConcediu
                    .Where(c => c.AngajatId == angajatId && c.Stare == Modele.StareCerere.Aprobata)
                    .ToList() // Aducem în memorie pentru calculul diferenței de date
                    .Sum(c => (int)(c.DataSfarsit - c.DataStart).TotalDays + 1);

                return totalZileAcumulate - zileLuate;
            }
        }
        public int ZileRamase(int angajatId)
        {
            using (var db = new AppDbContext())
            {
                var cereriAprobate = db.CereriConcediu
                    .Where(c => c.AngajatId == angajatId &&
                                c.Stare == StareCerere.Aprobata)
                    .ToList(); 

                int zileFolosite = cereriAprobate.Sum(c =>
                    (c.DataSfarsit - c.DataStart).Days + 1);

                return 24 - zileFolosite;
            }
        }


        public IEnumerable<dynamic> AngajatiPeDepartament()
        {
            using (var db = new AppDbContext())
            {
                return db.Angajati
                    .GroupBy(a => a.Departament.Nume)
                    .Select(g => new
                    {
                        Departament = g.Key,
                        Numar = g.Count()
                    })
                    .ToList();
            }

        }

        public IEnumerable<dynamic> AniversariAzi()
        {
            DateTime azi = DateTime.Today;

            using (var db = new AppDbContext())
            {
                return db.Angajati
                    .Where(a =>
                        a.DataNastere.Day == azi.Day &&
                        a.DataNastere.Month == azi.Month)
                    .Select(a => new
                    {
                        a.Nume,
                        a.Prenume,
                        DataNastere = a.DataNastere,
                        Departament = a.Departament.Nume
                    })
                    .ToList();
            }
        }





    }
}
