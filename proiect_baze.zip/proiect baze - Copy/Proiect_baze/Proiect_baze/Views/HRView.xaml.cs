﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Proiect_baze.Data;
using Proiect_baze.Modele;
using Proiect_baze.Servicii;

namespace Proiect_baze.Views
{
    public partial class HRView : UserControl
    {
        public HRView()
        {
            InitializeComponent();
            IncarcaCereri();
            IncarcaStatistici();
            IncarcaDepartamente();
            IncarcaAniversari();

        }

        private void IncarcaCereri()
        {
            using (var db = new AppDbContext())
            {
                CereriGrid.ItemsSource = db.CereriConcediu.ToList();
            }
        }

        private void Aproba_Click(object sender, RoutedEventArgs e)
        {
            if (CereriGrid.SelectedItem is CerereConcediu cerere)
            {
                using (var db = new AppDbContext())
                {
                    var c = db.CereriConcediu.Find(cerere.Id);
                    c.Stare = StareCerere.Aprobata;

                    db.AprobariConcediu.Add(new AprobareConcediu
                    {
                        CerereConcediuId = c.Id,
                        ManagerId = 3, // HR manager
                        DataAprobarii = DateTime.Now,
                        Aprobata = true
                    });

                    db.SaveChanges();
                }

                IncarcaCereri();
            }
        }

        private void IncarcaStatistici()
        {
            var service = new StatisticiService();

            DepartamenteGrid.ItemsSource =
                service.AngajatiPeDepartament() as System.Collections.IEnumerable;

            AniversariGrid.ItemsSource =
                service.AniversariAzi() as System.Collections.IEnumerable;
        }



        private void Respinge_Click(object sender, RoutedEventArgs e)
        {
            if (CereriGrid.SelectedItem is CerereConcediu cerere)
            {
                using (var db = new AppDbContext())
                {
                    var c = db.CereriConcediu.Find(cerere.Id);
                    c.Stare = StareCerere.Respinsa;
                    db.SaveChanges();
                }

                IncarcaCereri();
            }
        }


        private void GenereazaFluturasi_Click(object sender, RoutedEventArgs e)
        {
            int luna = DateTime.Now.Month;
            int an = DateTime.Now.Year;

            var salarizare = new SalarizareService();

            using (var db = new AppDbContext())
            {
                var angajati = db.Angajati.Select(a => a.Id).ToList();

                foreach (var angajatId in angajati)
                {
                    // verificăm să nu existe deja fluturaș
                    bool exista = db.Fluturasi.Any(f =>
                        f.AngajatId == angajatId &&
                        f.Luna == luna &&
                        f.An == an);

                    if (!exista)
                    {
                        salarizare.GenereazaFluturas(angajatId, luna, an);
                    }
                }
            }

            MessageBox.Show("Fluturasii au fost generati!");
        }


        private void IncarcaDepartamente()
        {
            var service = new StatisticiService();
            DepartamenteGrid.ItemsSource = service.AngajatiPeDepartament();
        }


        private void IncarcaAniversari()
        {
            var service = new StatisticiService();
            AniversariGrid.ItemsSource = service.AniversariAzi();
        }




    }
}
