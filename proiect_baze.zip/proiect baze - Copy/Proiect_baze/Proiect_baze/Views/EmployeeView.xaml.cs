﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Proiect_baze.Data;
using Proiect_baze.Modele;
using Proiect_baze.Servicii;

namespace Proiect_baze.Views
{
    public partial class EmployeeView : UserControl
    {
        private Utilizator _user;

        public EmployeeView(Utilizator user)
        {
            InitializeComponent();
            _user = user;

            AfiseazaZileRamase();
            IncarcaCererile();
            IncarcaFluturasi();
        }

        private void IncarcaCererile()
        {
            using (var db = new AppDbContext())
            {
                CererileGrid.ItemsSource = db.CereriConcediu
                    .Where(c => c.AngajatId == _user.AngajatId)
                    .ToList();
            }
        }


        private void AfiseazaZileRamase()
        {
            var service = new StatisticiService();
            int ramase = service.ZileRamase(_user.AngajatId.Value);

            ZileRamaseText.Text = $"Zile concediu rămase: {ramase}";
        }


        private void IncarcaFluturasi()
        {
            using (var db = new AppDbContext())
            {
                FluturasiGrid.ItemsSource = db.Fluturasi
                    .Where(f => f.AngajatId == _user.AngajatId)
                    .ToList();
            }
        }

        private void TrimiteCerere_Click(object sender, RoutedEventArgs e)
        {
            if (DataStartPicker.SelectedDate == null || DataEndPicker.SelectedDate == null)
            {
                MessageBox.Show("Selecteaza datele!");
                return;
            }

            var tip = TipConcediuBox.SelectedIndex == 1
                ? TipConcediu.Medical
                : TipConcediu.Anual;

            using (var db = new AppDbContext())
            {
                var cerere = new CerereConcediu
                {
                    AngajatId = _user.AngajatId.Value,
                    DataStart = DataStartPicker.SelectedDate.Value,
                    DataSfarsit = DataEndPicker.SelectedDate.Value,
                    Tip = tip,
                    Stare = StareCerere.InAsteptare,
                    DataCreare = DateTime.Now
                };

                db.CereriConcediu.Add(cerere);
                db.SaveChanges();
            }

            MessageBox.Show("Cerere trimisa!");
            IncarcaCererile();
        }
    }
}
