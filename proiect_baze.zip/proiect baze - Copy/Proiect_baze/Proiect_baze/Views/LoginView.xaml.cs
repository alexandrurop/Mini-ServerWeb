﻿using System.Windows;
using System.Windows.Controls;
using Proiect_baze.Security;
using Proiect_baze.Modele;

namespace Proiect_baze.Views
{
    public partial class LoginView : UserControl
    {
        public LoginView()
        {
            InitializeComponent();
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            var auth = new AuthService();
            Utilizator user = auth.Login(txtUser.Text, txtPass.Password);

            if (user == null)
            {
                MessageBox.Show("Username sau parola incorecte");
                return;
            }

            ((MainWindow)Application.Current.MainWindow)
                .Autentificat(user);
        }
    }
}
