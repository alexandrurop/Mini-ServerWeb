﻿using System.Linq;
using Proiect_baze.Data;
using Proiect_baze.Modele;

namespace Proiect_baze.Security
{
    public class AuthService
    {
        public Utilizator Login(string username, string parola)
        {
            using (var db = new AppDbContext())
            {
                return db.Utilizatori
                    .FirstOrDefault(u =>
                        u.Username == username &&
                        u.Parola == parola);
            }
        }
    }
}
