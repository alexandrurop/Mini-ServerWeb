﻿

//using System.Windows;
//using Proiect_baze.Data;
//using Proiect_baze.Modele;
//using Proiect_baze.Views;

//namespace Proiect_baze
//{
//    public partial class MainWindow : Window
//    {
//        public MainWindow()
//        {
//            InitializeComponent();

//            MessageBox.Show("INAINTE de DB");

//            using (var db = new AppDbContext())
//            {
//                db.Database.CreateIfNotExists();
//            }

//            MessageBox.Show("DUPA DB");

//            MainContent.Content = new LoginView();
//        }

//        // 🔴 ASTA LIPSEA
//        public void Autentificat(Utilizator user)
//        {
//            if (user.Rol == Rol.HRManager)
//            {
//                MainContent.Content = new HRView();
//            }
//            else
//            {
//                MainContent.Content = new EmployeeView(user);
//            }
//        }
//    }
//}



using System.Windows;
using Proiect_baze.Modele;
using Proiect_baze.Views;

namespace Proiect_baze
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            MainContent.Content = new LoginView();
        }

        public void Autentificat(Utilizator user)
        {
            if (user.Rol == Rol.HRManager)
                MainContent.Content = new HRView();
            else
                MainContent.Content = new EmployeeView(user);
        }
    }
}
