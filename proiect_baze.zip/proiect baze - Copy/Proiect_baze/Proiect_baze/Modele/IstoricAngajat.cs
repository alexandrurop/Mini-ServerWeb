﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proiect_baze.Modele
{
    public class IstoricAngajat
    {
        public int Id { get; set; }
        public int AngajatId { get; set; }

        public int DepartamentId { get; set; }
        public int PozitieId { get; set; }

        public DateTime DataStart { get; set; }
        public DateTime? DataSfarsit { get; set; }
    }

}
