﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proiect_baze.Modele
{
    public class AprobareConcediu
    {
        public int Id { get; set; }

        public int CerereConcediuId { get; set; }
        public CerereConcediu CerereConcediu { get; set; }

        public int ManagerId { get; set; }    
        public bool Aprobata { get; set; }      

        public DateTime DataAprobarii { get; set; }
    }

}
