﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proiect_baze.Modele
{
        public class Pozitie
        {
            public int Id { get; set; }
            public string Nume { get; set; }
        }
    
}

