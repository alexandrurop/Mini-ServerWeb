﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proiect_baze.Modele
{
    public enum Rol
    {
        HRManager = 0,
        Employee = 1
    }
}
