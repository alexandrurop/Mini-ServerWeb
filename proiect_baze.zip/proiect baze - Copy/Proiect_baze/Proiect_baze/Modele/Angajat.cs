﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proiect_baze.Modele
{
    public class Angajat
    {
        public int Id { get; set; }

        public string Nume { get; set; }
        public string Prenume { get; set; }
        public DateTime DataNastere { get; set; }

        public DateTime DataAngajare { get; set; }
        public bool Activ { get; set; }

        public int DepartamentId { get; set; }
        public int PozitieId { get; set; }

        public int? SefId { get; set; }

        public decimal SalariuBrut { get; set; }

        public Departament Departament { get; set; }

    }


}
