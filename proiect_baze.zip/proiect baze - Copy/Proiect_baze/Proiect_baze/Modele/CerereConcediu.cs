﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proiect_baze.Modele
{

    public class CerereConcediu
    {
        public int Id { get; set; }

        public int AngajatId { get; set; }
        public Angajat Angajat { get; set; }

        public TipConcediu Tip { get; set; }

        public DateTime DataStart { get; set; }
        public DateTime DataSfarsit { get; set; }   // ← OBLIGATORIU

        public StareCerere Stare { get; set; }

        public DateTime DataCreare { get; set; }
    }

}
