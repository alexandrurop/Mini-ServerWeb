﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proiect_baze.Modele
{
    public class PontajLunar
    {
        public int Id { get; set; }
        public int AngajatId { get; set; }

        public int Luna { get; set; }
        public int An { get; set; }

        public int OreLucrate { get; set; }
        public int OreSuplimentare { get; set; }
    }

}
