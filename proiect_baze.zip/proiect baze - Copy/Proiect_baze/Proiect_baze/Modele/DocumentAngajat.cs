﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proiect_baze.Modele
{
    public class DocumentAngajat
    {
        public int Id { get; set; }

        public int AngajatId { get; set; }
        public string Tip { get; set; }     // Contract, Act aditional etc.
        public string CaleFisier { get; set; }
    }

}
