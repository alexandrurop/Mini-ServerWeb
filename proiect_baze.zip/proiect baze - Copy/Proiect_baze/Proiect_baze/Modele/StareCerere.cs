﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proiect_baze.Modele
{
        public enum StareCerere
        {
            InAsteptare = 0,
            Aprobata = 1,
            Respinsa = 2
        }
   
}
