﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proiect_baze.Modele
{

    public class Utilizator
    {
        public int Id { get; set; }

        public string Username { get; set; }
        public string Parola { get; set; }

        public Rol Rol { get; set; }

        public int? AngajatId { get; set; }
    }

}
