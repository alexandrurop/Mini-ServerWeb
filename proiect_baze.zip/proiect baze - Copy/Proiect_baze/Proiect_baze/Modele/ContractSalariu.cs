﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proiect_baze.Modele
{
    public class ContractSalariu
    {
        public int Id { get; set; }

        public int AngajatId { get; set; }
        public Angajat Angajat { get; set; }

        public decimal SalariuBrut { get; set; }
        public decimal ValoareOra { get; set; }

        public DateTime DataStart { get; set; }
        public DateTime? DataEnd { get; set; }
    }

}
