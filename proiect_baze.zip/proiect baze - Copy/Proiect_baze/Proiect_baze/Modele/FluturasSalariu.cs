﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proiect_baze.Modele
{
    public class FluturasSalariu
    {
        public int Id { get; set; }

        public int AngajatId { get; set; }
        public Angajat Angajat { get; set; }

        public int Luna { get; set; }
        public int An { get; set; }

        public decimal Brut { get; set; }
        public decimal Net { get; set; }
        public decimal Taxe { get; set; }   // ← OBLIGATORIU

        public DateTime GeneratLa { get; set; }
    }

}
