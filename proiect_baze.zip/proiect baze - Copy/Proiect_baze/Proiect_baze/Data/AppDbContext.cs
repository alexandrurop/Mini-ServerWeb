﻿using System.Data.Entity;
using Proiect_baze.Modele;

namespace Proiect_baze.Data
{
    public class AppDbContext : DbContext
    {

        static AppDbContext()
        {
            Database.SetInitializer(
                new CreateDatabaseIfNotExists<AppDbContext>()
            );
        }

        public AppDbContext() : base("AppDbContext")
        {
        }

        // organizare angajati 
        public DbSet<Angajat> Angajati { get; set; }
        public DbSet<Departament> Departamente { get; set; }
        public DbSet<Pozitie> Pozitii { get; set; }
        public DbSet<IstoricAngajat> IstoricAngajati { get; set; }

        // utilizatori
        public DbSet<Utilizator> Utilizatori { get; set; }

        //concedii
        public DbSet<CerereConcediu> CereriConcediu { get; set; }
        public DbSet<AprobareConcediu> AprobariConcediu { get; set; }

        // salarizare
        public DbSet<ContractSalariu> ContracteSalariu { get; set; }
        public DbSet<PontajLunar> Pontaje { get; set; }
        public DbSet<FluturasSalariu> Fluturasi { get; set; }

        // documente
        public DbSet<DocumentAngajat> Documente { get; set; }
    }
}
