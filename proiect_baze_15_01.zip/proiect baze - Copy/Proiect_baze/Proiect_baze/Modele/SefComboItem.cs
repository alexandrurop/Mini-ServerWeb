﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proiect_baze.Modele
{

        public class SefComboItem
        {
            public int? Id { get; set; }
            public string NumeComplet { get; set; }
        }

}
